import random


def generate_phone_number():
    area_code = ['136', '137', '138', '139', '150', '151', '152', '157', '158', '159']
    # 以上是常用的手机号段，也可以根据需要添加其他区号前缀
    phone_number = random.choice(area_code) + ''.join(random.sample('0123456789', 8))
    return phone_number
