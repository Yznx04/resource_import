import random
from typing import Dict

from starlette.testclient import TestClient

from tests.utils.common import random_lower_string


def create_test_tag() -> Dict[str, str]:
    tag = {
        "tag_name": random_lower_string()
    }
    return tag


def test_create_tag(client: TestClient, user_token: str) -> None:
    create_url = "/api/v1/tag/"
    test_tag = create_test_tag()
    headers = {"Authorization": f"Bearer {user_token}"}
    # 正常测试
    response = client.post(create_url, json=test_tag, headers=headers)
    assert response.status_code == 200
    assert response.json()["data"]["tag_name"] == test_tag["tag_name"]
    # 异常测试
    error_response = client.post(create_url, json=test_tag, headers=headers)
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "该标签已存在。"


def test_delete_tag(client: TestClient, user_token: str) -> None:
    base_url = "/api/v1/tag/"
    headers = {"Authorization": f"Bearer {user_token}"}
    test_tag = create_test_tag()
    create_response = client.post(base_url, json=test_tag, headers=headers).json()["data"]
    tag_id = create_response.get("id")
    # 正常测试
    response = client.delete(f"{base_url}{tag_id}", headers=headers)
    assert response.status_code == 200
    # 异常测试
    error_response = client.delete(f"{base_url}{random.randint(10, 100)}", headers=headers)
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"


def test_get_tag_by_id(client: TestClient, user_token: str) -> None:
    base_url = "/api/v1/tag/"
    headers = {"Authorization": f"Bearer {user_token}"}
    test_tag = create_test_tag()
    create_response = client.post(base_url, json=test_tag, headers=headers).json()["data"]
    tag_id = create_response.get("id")
    # 正常测试
    response = client.get(f"{base_url}{tag_id}", headers=headers)
    assert response.status_code == 200
    response_content = response.json().get("data")
    assert response_content["tag_name"] == test_tag["tag_name"]
    # 异常测试
    error_response = client.delete(f"{base_url}{random.randint(10, 100)}", headers=headers)
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"


def test_get_user_tag(client: TestClient, user_token: str) -> None:
    # 生成多个测试数据
    number = 5
    base_url = "/api/v1/tag/"
    headers = {"Authorization": f"Bearer {user_token}"}
    for _ in range(number):
        test_tag = create_test_tag()
        client.post(base_url, json=test_tag, headers=headers)
    # 正常测试
    response = client.get(base_url, headers=headers)
    assert response.status_code == 200


def test_update_tag(client: TestClient, user_token: str) -> None:
    base_url = "/api/v1/tag/"
    headers = {"Authorization": f"Bearer {user_token}"}
    test_tag = create_test_tag()
    create_response = client.post(base_url, json=test_tag, headers=headers).json()
    tag_id = create_response.get("data").get("id")
    update_tag = create_test_tag()
    update_tag["id"] = tag_id
    # 正常测试
    response = client.put(base_url, headers=headers, json=update_tag)
    assert response.status_code == 200
    response_content = response.json().get("data")
    assert response_content["tag_name"] == update_tag["tag_name"]
    # 异常测试
    error_tag = create_test_tag()
    error_tag["id"] = random.randint(10, 100)
    error_response = client.put(base_url, headers=headers, json=error_tag)
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"
