import copy
import random
from typing import Dict

from fastapi.testclient import TestClient

from tests.utils.common import random_lower_string
from tests.utils.user import generate_phone_number


def create_test_user_dict() -> Dict[str, str]:
    test_user = {
        "name": random_lower_string(),
        "phone": generate_phone_number(),
        "password": random_lower_string()
    }
    return test_user


def test_create_user(client: TestClient) -> None:
    test_user = create_test_user_dict()
    create_user_url = "/api/v1/user/"
    # 正常用户测试
    response = client.post(create_user_url, json=test_user)
    assert response.status_code == 200
    assert response.json()["data"]["name"] == test_user["name"]
    assert response.json()["data"]["phone"] == test_user["phone"]
    # 异常用户测试
    error_response = client.post(create_user_url, json=test_user)
    assert error_response.status_code == 400


def test_get_user_by_token(client: TestClient) -> None:
    create_user_url = "/api/v1/user/"
    get_token_url = "/api/v1/user/token/"
    get_user_url = "/api/v1/user/me/"
    test_user = create_test_user_dict()
    _ = client.post(create_user_url, json=test_user).json()
    token_data = {
        "username": test_user["phone"], "password": test_user["password"]
    }
    # 异常获取Token
    error_token_data = copy.deepcopy(token_data)
    error_token_data["password"] = random_lower_string()
    error_token_response = client.post(get_token_url, data=error_token_data)
    assert error_token_response.status_code == 401
    assert error_token_response.json()["detail"] == "Incorrect username or password"

    token = client.post(get_token_url, data=token_data).json()["access_token"]
    # 正常测试
    response = client.get(get_user_url, headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json()["data"]["name"] == test_user["name"]
    assert response.json()["data"]["phone"] == test_user["phone"]
    # 异常测试
    error_response = client.get(get_user_url, headers={"Authorization": "Bearer error_token"})
    assert error_response.status_code == 401
    assert error_response.json()["detail"] == "Could not validate credentials"


def test_get_user_by_id(client: TestClient) -> None:
    create_user_url = "/api/v1/user/"
    base_url = "/api/v1/user/"
    test_user = create_test_user_dict()
    create_user_response = client.post(create_user_url, json=test_user).json()["data"]
    user_id = create_user_response["id"]
    # 正常测试
    get_user_response = client.get(f"{base_url}{user_id}")
    assert get_user_response.status_code == 200
    assert get_user_response.json()["data"]["name"] == test_user["name"]
    assert get_user_response.json()["data"]["phone"] == test_user["phone"]
    assert get_user_response.json()["data"]["id"] == user_id
    # 异常测试
    error_response = client.get(f"{base_url}{random.randint(10, 100)}")
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"


def test_delete_user_by_id(client: TestClient) -> None:
    create_user_url = "/api/v1/user/"
    base_url = "/api/v1/user/"
    test_user = create_test_user_dict()
    create_user_response = client.post(create_user_url, json=test_user).json()["data"]
    user_id = create_user_response["id"]
    print(user_id)
    print(f"{base_url}{user_id}/")
    # 正常流程
    response = client.delete(f"{base_url}{user_id}/")
    assert response.status_code == 200
    assert response.json()["data"]["id"] == user_id
    # 异常测试
    error_response = client.delete(f"{base_url}{random.randint(10, 100)}")
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"


def test_update_user_by_id(client: TestClient) -> None:
    create_user_url = "/api/v1/user/"
    base_url = "/api/v1/user/"
    test_user = create_test_user_dict()
    create_user_response = client.post(create_user_url, json=test_user).json()["data"]
    update_user = copy.deepcopy(create_user_response)
    update_user["name"] = random_lower_string()
    update_user["phone"] = generate_phone_number()
    update_user["password"] = random_lower_string()
    # 正常测试
    update_response = client.put(base_url, json=update_user)
    assert update_response.status_code == 200
    assert update_response.json()["data"]["phone"] == update_user["phone"]
    assert update_response.json()["data"]["name"] == update_user["name"]
    # 异常测试
    create_user_response["id"] = random.randint(10, 100)
    error_response = client.put(base_url, json=create_user_response)
    assert error_response.status_code == 400
    assert error_response.json()["detail"] == "错误ID。"
