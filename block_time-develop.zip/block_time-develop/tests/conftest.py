from typing import Generator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy_utils import database_exists, create_database

from application.api.dp import get_db
from application.extension.database.base import Base
from config import setting
from tests.api.v1.test_user import create_test_user_dict

test_engine = create_engine(str(setting.TEST_SQLALCHEMY_DATABASE_URL))
test_session = sessionmaker(bind=test_engine)


def get_test_db():
    db = test_session()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(scope="session")
def testapp():
    from main import application
    if not database_exists(test_engine.url):
        create_database(test_engine.url)
    Base.metadata.create_all(bind=test_engine)

    application.dependency_overrides[get_db] = get_test_db
    yield application
    Base.metadata.drop_all(bind=test_engine)


@pytest.fixture(scope="session")
def client(testapp) -> Generator:
    with TestClient(testapp) as c:
        yield c


@pytest.fixture(scope="session")
def user_token(client: TestClient):
    create_user_url = "/api/v1/user/"
    get_token_url = "/api/v1/user/token/"
    user_dict = create_test_user_dict()
    client.post(create_user_url, json=user_dict)
    form = {"username": user_dict["phone"], "password": user_dict["password"]}
    token = client.post(get_token_url, data=form).json()
    yield token["access_token"]
