from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.middleware.cors import CORSMiddleware

from application.api import api_router
from application.extension.middleware.db import DBSessionMiddleware
from application.extension.utils.events import startup, shutdown
from application.extension.utils.exceptions import http422_error_handler
from config import setting


def create_application() -> FastAPI:
    app = FastAPI(
        debug=setting.DEBUG,
        title=setting.APP_NAME,
        version=setting.VERSION
    )
    # 注册中间件
    app.add_middleware(DBSessionMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=setting.CORS_ORIGINS,
        allow_credentials=setting.CORS_ALLOW_CREDENTIALS,
        allow_methods=setting.CORS_ALLOW_METHODS,
        allow_headers=setting.CORS_ALLOW_HEADERS,

    )
    # 注册路由
    app.include_router(api_router)
    # 事件注册
    app.add_event_handler("startup", startup(app))
    app.add_event_handler("shutdown", shutdown(app))
    # 注册错误处理
    app.add_exception_handler(RequestValidationError, http422_error_handler)
    return app
