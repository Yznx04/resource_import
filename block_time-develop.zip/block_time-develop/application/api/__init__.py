from importlib import import_module

from fastapi import APIRouter

from config import setting

api_router = APIRouter(prefix="/api")

for version in setting.ENABLE_API_MODULE:
    version_module = import_module(f".{version}", package=__name__)
    version_router = getattr(version_module, "router")
    api_router.include_router(version_router)
