from importlib import import_module

from fastapi import APIRouter

from config import setting

router = APIRouter(prefix="/v1")
module_list = setting.ENABLE_API_MODULE.get("v1", [])

for module in module_list:
    _module = import_module(f".{module}", package=__name__)
    module_router = getattr(_module, "router")
    router.include_router(module_router)
