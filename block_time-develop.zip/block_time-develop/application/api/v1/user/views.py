from typing import Dict

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from application.api.dp import get_db
from application.api.v1.user.models import User
from application.api.v1.user.schema import UserInDB, CreateUser, UpdateUser
from application.api.v1.user.server import crud_user
from application.extension.utils.response import CustomResponse
from application.extension.utils.security import create_access_token, verify_password, get_password_hash, \
    get_current_user

router = APIRouter(prefix="/user", tags=["用户"])


@router.post("/token", response_model=Dict, summary="Token获取接口")
def login_for_access_token(
        form_data: OAuth2PasswordRequestForm = Depends(),
        db: Session = Depends(get_db)
) -> Dict:
    user = crud_user.get_user_by_phone(db=db, phone=form_data.username)
    if not user or not verify_password(plain_password=form_data.password, hashed_password=user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(data={"sub": user.phone})
    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/", response_model=CustomResponse[UserInDB], summary="用户创建接口")
def create_user(
        user_in: CreateUser,
        db: Session = Depends(get_db)
) -> CustomResponse:
    old_user = crud_user.get_user_by_phone(db=db, phone=user_in.phone)
    if old_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="手机号已经被注册。"
        )
    # 将明文密码加密再存放到数据库当中
    user_in.password = get_password_hash(user_in.password)
    user = crud_user.create(db=db, object_in=user_in)
    return CustomResponse(data=user)


@router.get("/me/", response_model=CustomResponse[UserInDB], summary="根据Token获取用户信息")
def read_user_me(current_user: User = Depends(get_current_user)) -> CustomResponse:
    return CustomResponse(data=current_user)


@router.get("/{id_}", response_model=CustomResponse[UserInDB], summary="根据用户ID获取用户信息")
def read_user_by_id(id_: int, db: Session = Depends(get_db)) -> CustomResponse:
    user = crud_user.get(db=db, id_=id_)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    return CustomResponse(data=user)


@router.delete("/{id_}", response_model=CustomResponse[UserInDB], summary="根据用户ID删除用户")
def remove_user_by_id(id_: int, db: Session = Depends(get_db)) -> CustomResponse:
    user = crud_user.get(db=db, id_=id_)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    user = crud_user.remove(db=db, id_=id_)
    return CustomResponse(data=user)


@router.put("/", response_model=CustomResponse[UserInDB], summary="根据ID更新用户信息")
def update_user_by_id(user_in: UpdateUser, db: Session = Depends(get_db)) -> CustomResponse:
    user_in_db = crud_user.get(db=db, id_=user_in.id)
    if not user_in_db:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    if user_in.password:
        user_in.password = get_password_hash(user_in.password)
    new_user = crud_user.update(db=db, db_obj=user_in_db, obj_in=user_in)
    return CustomResponse(data=new_user)
