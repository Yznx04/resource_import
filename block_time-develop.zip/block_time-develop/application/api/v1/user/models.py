from sqlalchemy import Column, SmallInteger, VARCHAR

from application.extension.database.base_model import Base, TimeMixin


class User(Base, TimeMixin):
    id = Column(SmallInteger, primary_key=True, index=True, autoincrement=True, comment="ID")
    name = Column(VARCHAR(256), comment="用户名")
    phone = Column(VARCHAR(16), nullable=False, index=True, comment="电话号码")
    password = Column(VARCHAR(256), nullable=False, comment="密码")

    __table_arg__ = {"comment": "用户表"}
