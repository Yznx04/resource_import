from sqlalchemy.orm import Session

from application.api.v1.user.models import User
from application.api.v1.user.schema import CreateUser, UpdateUser
from application.extension.database.base_model import CRUDBase


class CRUDUser(CRUDBase[User, CreateUser, UpdateUser]):
    def get_user_by_phone(self, db: Session, phone: str) -> User:
        return db.query(self.model).filter(self.model.phone == phone).one_or_none()


crud_user = CRUDUser(User)
