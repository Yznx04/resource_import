import datetime

from pydantic import BaseModel, Field


class CreateUser(BaseModel):
    name: str = Field(..., max_length=256, description="用户名")
    phone: str = Field(..., max_length=16, description="电话号码")
    password: str = Field(..., max_length=16, description="密码，最长长度不超过16位")


class UpdateUser(BaseModel):
    id: int
    name: str = Field(None, max_length=256, description="用户名")
    phone: str = Field(None, max_length=16, description="电话号码")
    password: str = Field(None, max_length=16, description="密码，最长长度不超过16位")
    update_time: datetime.datetime = datetime.datetime.now()


class UserInDB(BaseModel):
    id: int
    name: str
    phone: str

    class Config:
        orm_mode = True
