from sqlalchemy import Column, SmallInteger, VARCHAR, Text

from application.extension.database.base_model import Base, TimeMixin


class Item(Base, TimeMixin):
    id = Column(SmallInteger, primary_key=True, index=True, autoincrement=True, comment="ID,主键")
    item_type = Column(VARCHAR(16), index=True, nullable=False, comment="事件类型，只有两个选项：I类时间、II类时间")
    item_text = Column(Text, nullable=False, comment="事件内容")
    item_duration = Column(SmallInteger, nullable=False, comment="事件耗时, 单位分钟")
    owner = Column(SmallInteger, nullable=False, comment="所属用户ID, 业务外键")
    __table_arg__ = {"comment": "事件表"}
