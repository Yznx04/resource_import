from datetime import datetime
from typing import List

from pydantic import BaseModel


class TagCreate(BaseModel):
    tag_name: str


class TagUpdate(TagCreate):
    id: int


class TagInDB(TagUpdate):
    create_at: datetime
    update_at: datetime

    class Config:
        orm_mode = True


class UserAllTag(BaseModel):
    total: int
    data: List[TagInDB]
