from sqlalchemy import Column, SmallInteger, VARCHAR

from application.extension.database.base_model import Base, TimeMixin


class Tag(Base, TimeMixin):
    id = Column(SmallInteger, primary_key=True, index=True, autoincrement=True, comment="ID")
    tag_name = Column(VARCHAR(256), nullable=False, comment="tag名")
    owner = Column(SmallInteger, nullable=False, index=True, comment="所属用户ID")
    __table_arg__ = {"comment": "标签表"}


class Relation(Base, TimeMixin):
    id = Column(SmallInteger, primary_key=True, index=True, autoincrement=True, comment="ID")
    item_id = Column(SmallInteger, nullable=False, comment="事件ID")
    tag_id = Column(SmallInteger, nullable=False, comment="标签ID")
    __table_arg__ = {"comment": "事件与标签关系映射表"}
