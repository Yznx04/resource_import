from typing import List, Tuple

from sqlalchemy.orm import Session

from application.api.v1.tag.models import Tag
from application.api.v1.tag.schema import TagUpdate, TagCreate
from application.extension.database.base_model import CRUDBase


class CRUDTag(CRUDBase[Tag, TagCreate, TagUpdate]):
    def get_tag_with_owner(self, db: Session, owner_id: int) -> List[Tag]:
        all_tag = db.query(self.model).filter(self.model.owner == owner_id).all()
        return all_tag

    def get_user_tag_with_name(self, db: Session, *, tag_name: str, owner_id: int) -> Tag:
        return db.query(self.model).filter(self.model.tag_name == tag_name, self.model.owner == owner_id).one_or_none()

    def get_user_tag_with_id(self, db: Session, *, id_: int, owner_id: int) -> Tag:
        return db.query(self.model).filter(self.model.id == id_, self.model.owner == owner_id).one_or_none()

    def get_user_tag(self, db: Session, *, owner_id: int, skip: int = 0, limit: int = 20) -> Tuple[int, List[Tag]]:
        all_tag = db.query(self.model).filter(self.model.owner == owner_id).offset(skip).limit(limit)
        return all_tag.count(), all_tag.all()


crud_tag = CRUDTag(Tag)
