from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from starlette import status

from application.api.dp import get_db
from application.api.v1.tag.schema import TagCreate, TagInDB, UserAllTag, TagUpdate
from application.api.v1.tag.server import crud_tag
from application.api.v1.user.models import User
from application.extension.utils.response import CustomResponse
from application.extension.utils.security import get_current_user

router = APIRouter(prefix="/tag", tags=["标签"])


@router.post("/", response_model=CustomResponse[TagInDB], summary="标签创建接口")
def create_tag(
        tag_in: TagCreate,
        owner: User = Depends(get_current_user),
        db: Session = Depends(get_db)
) -> CustomResponse[TagInDB]:
    tag_obj = crud_tag.get_user_tag_with_name(db=db, tag_name=tag_in.tag_name, owner_id=owner.id)
    if tag_obj:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="该标签已存在。"
        )
    tag_info = tag_in.dict()
    tag_info.update({"owner": owner.id})
    tag_obj = crud_tag.create(db=db, object_in=tag_info)
    return CustomResponse(data=tag_obj)


@router.delete("/{id_}", response_model=CustomResponse[TagInDB], summary="根据标签ID删除标签接口")
def delete_tag_by_id(
        id_: int,
        owner: User = Depends(get_current_user),
        db: Session = Depends(get_db)
) -> CustomResponse[TagInDB]:
    tag_obj = crud_tag.get_user_tag_with_id(db=db, id_=id_, owner_id=owner.id)
    if not tag_obj:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    tag_obj = crud_tag.remove(db=db, id_=id_)
    return CustomResponse(data=tag_obj)


@router.get("/{id_}", response_model=CustomResponse[TagInDB], summary="根据标签ID获取标签信息")
def get_tag_by_id(
        id_: int,
        owner: User = Depends(get_current_user),
        db: Session = Depends(get_db)
) -> CustomResponse[TagInDB]:
    tag_obj = crud_tag.get_user_tag_with_id(db=db, id_=id_, owner_id=owner.id)
    if not tag_obj:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    return CustomResponse(data=tag_obj)


@router.get("/", response_model=CustomResponse[UserAllTag], summary="获取用户所有的标签")
def get_user_tag(
        owner: User = Depends(get_current_user),
        db: Session = Depends(get_db),
        skip: int = 0,
        limit: int = 20
) -> CustomResponse[UserAllTag]:
    total, all_tag = crud_tag.get_user_tag(db, owner_id=owner.id, skip=skip, limit=limit)
    return CustomResponse(data=UserAllTag(total=total, data=all_tag))


@router.put("/", response_model=CustomResponse[TagInDB], summary="根据标签ID修改标签")
def update_tag_by_id(
        tag_update: TagUpdate,
        owner: User = Depends(get_current_user),
        db: Session = Depends(get_db)
) -> CustomResponse[TagInDB]:
    tag_obj = crud_tag.get_user_tag_with_id(db=db, id_=tag_update.id, owner_id=owner.id)
    if not tag_obj:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="错误ID。"
        )
    tag_obj = crud_tag.update(db=db, db_obj=tag_obj, obj_in=tag_update)
    return CustomResponse(data=tag_obj)
