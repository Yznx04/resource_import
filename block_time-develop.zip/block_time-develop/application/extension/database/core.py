from sqlalchemy import create_engine

from config import setting

engine = create_engine(url=str(setting.SQLALCHEMY_DATABASE_URL), pool_pre_ping=True)
