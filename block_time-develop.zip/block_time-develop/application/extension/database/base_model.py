import datetime
import re
from typing import Any, Generic, TypeVar, Type, Optional, List, Union, Dict

from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel
from sqlalchemy import Column, DateTime, event
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import Session, as_declarative

from config import setting


@as_declarative()
class Base:
    id: Any
    __name__: str

    @declared_attr
    def __tablename__(cls) -> str:
        table_name = "_".join(re.sub(r"([A-Z]{1}[a-z]{1,})", r" \1", cls.__name__).split()).lower()  # noqa
        return f"{setting.DATABASE_TABLE_PREFIX.lower()}_{table_name}"


# SQLAlchemy的模型
class TimeMixin(object):
    """时间注入类"""
    create_at = Column(DateTime, default=datetime.datetime.now)
    update_at = Column(DateTime, default=datetime.datetime.now)

    @staticmethod
    def _update_at(mapper, connection, target):
        target.update_at = datetime.datetime.now()

    @classmethod
    def __declare_last(cls):
        event.listen(cls, "before_update", cls._update_at)


# SQLAlchemy查询基类
ModelType = TypeVar("ModelType", bound=Base)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class CRUDBase(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    def __init__(self, model: Type[ModelType]):
        self.model = model

    def get(self, db: Session, id_: int) -> Optional[ModelType]:
        return db.query(self.model).filter(self.model.id == id_).one_or_none()

    def get_multi(self, db: Session, *, skip: int = 0, limit: int = 20) -> List[ModelType]:
        return db.query(self.model).offset(skip).limit(limit).all()

    def create(self, db: Session, *, object_in: CreateSchemaType) -> ModelType:
        object_in_data = jsonable_encoder(object_in)
        db_obj = self.model(**object_in_data)
        try:
            db.add(db_obj)
            db.commit()
            db.refresh(db_obj)
            return db_obj
        except Exception as e:
            print(f"插入数据表{self.model}时出错，错误是：{e}")
            db.rollback()

    def update(self, db: Session, *, db_obj: ModelType, obj_in: Union[CreateSchemaType, Dict]):
        obj_data = jsonable_encoder(db_obj)
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        for field in obj_data:
            if field in update_data:
                setattr(db_obj, field, update_data[field])
        try:
            db.add(db_obj)
            db.commit()
            db.refresh(db_obj)
            return db_obj
        except Exception as e:
            print(f"更新数据表{self.model}:ID为:{db_obj.id}的数据时出错，错误是：{e}")
            db.rollback()

    def remove(self, db: Session, id_: int) -> ModelType:
        obj = db.query(self.model).filter(self.model.id == id_).first()
        db.delete(obj)
        db.commit()
        return obj

    def remove_multi(self, db: Session, all_id: List[int]) -> bool:
        try:
            db.query(self.model).filter(self.model.id.in_(all_id)).delete(synchronize_session=False)
            db.commit()
        except Exception:
            db.rollback()
            return False
        return True
