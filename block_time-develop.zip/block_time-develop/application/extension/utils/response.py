from typing import TypeVar, Generic

from pydantic.generics import GenericModel

T = TypeVar("T")


class CustomResponse(GenericModel, Generic[T]):
    code: int = 200
    message: str = "Successful"
    data: T
