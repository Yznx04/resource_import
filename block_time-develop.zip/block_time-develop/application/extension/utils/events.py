import platform
from typing import Callable

from fastapi import FastAPI


def startup(app: FastAPI) -> Callable:
    async def app_start() -> None:
        run_os = platform.system()
        print(f"程序当前运行在{run_os}系统上")
        pass

    return app_start


def shutdown(app: FastAPI) -> Callable:
    async def app_stop() -> None:
        print(f"FastAPI应用已停止")
        pass

    return app_stop
