from typing import List, Dict, Optional, Any

from pydantic import BaseSettings, validator

_DATABASE_MAP = {
    "mysql": "pymysql",
    "postgresql": "psycopg2"
}


class SQLAlchemyType:  # 方便Setting类的实例
    def __init__(self, database_type: str, host: str, port: int, username: str, password: str, database: str):
        self.database_type = database_type
        self.database_host = host
        self.port = port
        self.username = username
        self.password = password
        self.database = database

    def __str__(self):
        url = f'{self.database_type}+{_DATABASE_MAP.get(self.database_type)}://{self.username}:{self.password}' \
              f'@{self.database_host}:{self.port}/{self.database}'
        return url


class Setting(BaseSettings):
    # 这里是配置项目
    APP_NAME: str = "BlockTime"
    DEBUG: bool = True
    VERSION: str = "0.1.0"
    ROOT_PATH: str = "/api"
    # 通过配置文件管理哪些模块需要启动
    ENABLE_API_MODULE: Dict[str, List] = {
        "v1": ["user", "tag"]
    }
    # 允许跨越的资源配置
    CORS_ORIGINS = ["*"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS = ["*"]
    CORS_ALLOW_HEADERS = ["*"]
    # Token配置
    EXPIRES_DELTA: int = 30
    SECRET_KEY: str = "secret_key_demo"
    # 开发数据库配置
    DATABASE_TABLE_PREFIX: str
    DATABASE_SERVER: str
    DATABASE_PORT: int
    DATABASE_USER: str
    DATABASE_PASSWORD: str
    DATABASE_NAME: str
    DATABASE_TYPE: str
    SQLALCHEMY_DATABASE_URL: Optional[SQLAlchemyType] = None

    @validator("SQLALCHEMY_DATABASE_URL", pre=True)
    def assemble_db_connection(cls, v: Optional[str], values: Dict[str, Any]) -> Any:
        if isinstance(v, str):
            return v

        return SQLAlchemyType(
            database_type=values.get("DATABASE_TYPE"),
            host=values.get("DATABASE_SERVER"),
            port=values.get("DATABASE_PORT"),
            username=values.get("DATABASE_USER"),
            password=values.get("DATABASE_PASSWORD"),
            database=values.get("DATABASE_NAME")
        )

    # 测试数据库配置项
    TEST_DATABASE_NAME: str
    TEST_SQLALCHEMY_DATABASE_URL: Optional[SQLAlchemyType] = None

    @validator("TEST_SQLALCHEMY_DATABASE_URL", pre=True)
    def assemble_test_db_connection(cls, v: Optional[str], values: Dict[str, Any]) -> Any:
        if isinstance(v, str):
            return v

        return SQLAlchemyType(
            database_type=values.get("DATABASE_TYPE"),
            host=values.get("DATABASE_SERVER"),
            port=values.get("DATABASE_PORT"),
            username=values.get("DATABASE_USER"),
            password=values.get("DATABASE_PASSWORD"),
            database=values.get("TEST_DATABASE_NAME")
        )

    class Config:
        env_file = ".env"


setting = Setting()
