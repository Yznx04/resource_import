import uvicorn

from application import create_application

application = create_application()

if __name__ == '__main__':
    uvicorn.run("main:application")
